/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectobuses;

import java.util.Scanner;

/**
 *
 * @author sergi
 */
public class Menu {
int selection;
String paradas; 
private Scanner input = new Scanner (System.in);
public void Menu(){
System.out.println("--bienvenido"+"por favor seleccione su opcion --");
System.out.println("Nuestro menu:\n "+" 1)"
+"consultar paradas \n"+
"2)consulte consultar buses "
+ "extendido\n"
);

           int selection = input.nextInt();
           input.nextLine();
switch(selection){
           case 1:
            paradas();
             break;
           case 2:
             paradas();
             break;
             default:
             System.out.println("ivalid selection.");
             break;

}





}



void paradas()
    {


System.out.println("por favor introduce el numero de bus");

String cedula = "" ;    
Scanner entradaEscanner = new Scanner (System.in);
cedula = entradaEscanner.nextLine() ;    
System.out.println("su numero de cedula que ingreso es: \""+cedula+"\"");
paradas paradas= new paradas();
buses=.buses(paradas);
System.out.println("su lugar de votacion:"+puntovotacion);

             
}
void consultarpuntosfestivos(){
System.out.println("los lugares de votacion son");
}
}


}
