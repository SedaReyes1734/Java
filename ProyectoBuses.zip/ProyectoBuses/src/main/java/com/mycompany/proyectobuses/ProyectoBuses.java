/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectobuses;

/**
 *
 * @author sergi
 */
public class ProyectoBuses {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
